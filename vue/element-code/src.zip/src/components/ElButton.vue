<template>
<div>
  {{type}} - {{tit}}
  <slot></slot>
</div>
</template>
<script>
// props 检查
export default {
  data(){
    return {
      tit:'hello'
    }
  },
  props:{
    type:{
      type:String,
      default:"default"
    }
  }
}
</script>
<style>

</style>